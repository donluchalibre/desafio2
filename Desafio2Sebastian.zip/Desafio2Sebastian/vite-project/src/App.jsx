import React from 'react';
import Registro from './components/Registro';
import './App.css'; // Asegúrate de tener estilos si es necesario

const App = () => (
    <div className="app">
        <Registro />
    </div>
);

export default App;
