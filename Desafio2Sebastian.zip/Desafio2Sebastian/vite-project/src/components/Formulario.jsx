import React, { useState } from 'react';
import Alert from './Alert';

const Formulario = ({ onSubmit }) => {
    const [nombre, setNombre] = useState('');
    const [email, setEmail] = useState('');
    const [error, setError] = useState('');

    const validarDatos = (e) => {
        e.preventDefault();
        if (!nombre || !email) {
            setError('Debes llenar todos los campos');
            return;
        }
        setError('');
        onSubmit(nombre, email);
    };

    return (
        <>
            <form className="formulario" onSubmit={validarDatos}>
                <div className="form-group">
                    <label>Nombre:</label>
                    <input
                        type="text"
                        className="form-control"
                        onChange={(e) => setNombre(e.target.value)}
                        value={nombre}
                    />
                </div>
                <div className="form-group">
                    <label>Email:</label>
                    <input
                        type="email"
                        className="form-control"
                        onChange={(e) => setEmail(e.target.value)}
                        value={email}
                    />
                </div>
                <Alert message={error} variant="danger" />
                <button type="submit" className="btn btn-primary">Unirse</button>
            </form>
        </>
    );
};

export default Formulario;
