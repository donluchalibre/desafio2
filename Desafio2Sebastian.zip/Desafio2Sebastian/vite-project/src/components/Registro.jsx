import React, { useState } from 'react';
import Formulario from './Formulario';
import Alert from './Alert';
import './Registro.css';

const Registro = () => {
    const [alertMessage, setAlertMessage] = useState('');
    const [alertVariant, setAlertVariant] = useState('success');

    const handleSubmit = (nombre, email) => {
        setAlertMessage(`¡Bienvenido, ${nombre}! Usted ya es un luchador!!.`);
        setAlertVariant('success');
    };

    return (
        <div className="registro-container">
            <h2>¡Asociación de Luchadores!</h2>
            <Alert message={alertMessage} variant={alertVariant} />
            <Formulario onSubmit={handleSubmit} />
            <footer className="footer">
                <p>¡Atangana!</p>
            </footer>
        </div>
    );
};

export default Registro;
